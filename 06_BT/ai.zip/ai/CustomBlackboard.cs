using UnityEngine;

namespace TheKiwiCoder {

    /// <summary>
    /// 🧠 [클래스 설명] CustomBlackboard
    ///
    /// TheKiwiCoder의 기본 Blackboard를 확장하여,
    /// AI(개구리)가 환경 정보를 기억하고 노드 간에 공유할 수 있도록 하는
    /// "사용자 정의 데이터 저장소"입니다.
    ///
    /// BehaviourTree 내의 여러 Action 노드들이
    /// 이 블랙보드를 통해 서로 데이터를 주고받습니다.
    ///
    /// 예시:
    ///  - CheckDangerNearby : 위험 감지 후 dangerX, isDangerNearby 값 설정
    ///  - AvoidDanger       : dangerX를 참조해 회피 방향 결정
    ///  - ReturnToCenter    : moveToPosition을 이용해 복귀
    /// </summary>
    [System.Serializable]
    public class CustomBlackboard : Blackboard {

        [Tooltip("AI가 이동해야 할 목표 위치 (회피 또는 복귀 시 사용)")]
        public Vector3 moveToPosition;  // 이동 목표 지점 (ex. 중앙, 회피 위치 등)

        [Tooltip("현재 위험이 감지되었는지 여부 (돌 감지 여부)")]
        public bool isDangerNearby;     // 위험 상태 (true면 돌이 근처에 있음)

        [Tooltip("가장 가까운 위험 요소(돌)의 X 좌표")]
        public float dangerX;           // 감지된 돌의 X 위치 (회피 방향 계산용)
    }
}
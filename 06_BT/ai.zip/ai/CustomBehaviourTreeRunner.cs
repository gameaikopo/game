using UnityEngine;

namespace TheKiwiCoder {
    /// <summary>
    /// 🧠 [클래스 설명] CustomBehaviourTreeRunner
    ///
    /// TheKiwiCoder의 기본 BehaviourTreeRunner를 확장하여,
    /// 사용자 정의 블랙보드(CustomBlackboard)를 트리에 연결하고
    /// AI가 실제 게임 환경(Context)에서 동작하도록 관리하는 실행기 클래스입니다.
    /// 
    /// 1️⃣ 트리(BehaviourTree) 복제 및 초기화
    /// 2️⃣ Context 생성 (게임 오브젝트 기반)
    /// 3️⃣ CustomBlackboard 생성 및 바인딩
    /// 4️⃣ 트리 업데이트를 매 프레임 수행
    /// </summary>
    public class CustomBehaviourTreeRunner : MonoBehaviour {

        [Tooltip("실행할 Behaviour Tree 에셋 (BT 에디터에서 연결 필요)")]
        public BehaviourTree tree;  // 실행할 Behaviour Tree 참조

        [System.NonSerialized]
        public CustomBlackboard customBlackboard;  // 개구리 AI용 커스텀 블랙보드

        private Context context;  // 현재 게임 오브젝트의 환경(Context) 정보

        /// <summary>
        /// Start() : 게임 시작 시 최초 1회 실행
        /// 트리, 블랙보드, 컨텍스트를 초기화하고 서로 연결합니다.
        /// </summary>
        void Start() {
            // 1️⃣ Context 생성 — 이 오브젝트의 Transform, Rigidbody 등 환경 정보 자동 수집
            context = Context.CreateFromGameObject(gameObject);

            // 🔸 트리 에셋이 연결되어 있지 않다면 에러 출력 후 실행 중단
            if (tree == null) {
                Debug.LogError("❌ Behaviour Tree가 연결되지 않았습니다!");
                return;
            }

            // 2️⃣ 트리 복제 및 바인딩 — 원본 에셋이 손상되지 않도록 복제 후 실행
            tree = tree.Clone();
            tree.Bind(context);  // 현재 오브젝트의 Context를 트리에 연결

            // 3️⃣ 커스텀 블랙보드 생성 — AI의 상태 정보를 저장할 사용자 정의 데이터 구조
            if (customBlackboard == null) {
                customBlackboard = new CustomBlackboard();
                Debug.Log("🧠 CustomBlackboard 생성됨 (비직렬화 상태)");
            }

            // 4️⃣ 트리 전체에 CustomBlackboard를 연결 — 모든 노드가 같은 블랙보드를 공유하게 함
            tree.blackboard = customBlackboard;
            BehaviourTree.Traverse(tree.rootNode, (node) => {
                node.blackboard = customBlackboard;
            });

            // ✅ 모든 연결 완료 로그
            Debug.Log("✅ BehaviourTree 및 Blackboard 연결 완료");
        }

        /// <summary>
        /// Update() : 매 프레임마다 실행
        /// 트리의 루트 노드를 갱신(Update)하여 AI 행동을 지속적으로 평가합니다.
        /// </summary>
        void Update() {
            if (tree != null) {
                tree.Update();  // 트리 내 각 노드 상태 갱신
            }
        }

        /// <summary>
        /// OnDrawGizmosSelected() : Unity Scene 뷰에서 기즈모(Gizmos)를 시각화하는 함수
        /// 트리의 노드 중 'drawGizmos'가 true인 노드의 OnDrawGizmos()를 호출합니다.
        /// </summary>
        private void OnDrawGizmosSelected() {
            // 트리가 존재하지 않으면 아무 작업도 하지 않음
            if (tree == null) return;

            // 트리의 모든 노드를 순회하면서 시각화할 노드를 찾아 그림
            BehaviourTree.Traverse(tree.rootNode, (n) => {
                if (n.drawGizmos) {
                    n.OnDrawGizmos();
                }
            });
        }
    }
}
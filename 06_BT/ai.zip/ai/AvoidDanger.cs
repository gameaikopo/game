// 2025-11-04 AI-Tag
// This was created with the help of Assistant, a Unity Artificial Intelligence product.

using UnityEngine; // ✅ UnityEngine.Random만 사용
// using System; ❌ 필요 없음
using UnityEditor;

public class BallManager : MonoBehaviour
{
    public GameObject[] balls; // Array to hold the ball GameObjects
    public Vector3 boxSize = new Vector3(10, 10, 10); // Size of the boundary box
    public float[] ballSpeeds; // Array to hold the speed of each ball

    private Vector3[] directions; // Array to hold the direction of each ball

    void Start()
    {
        if (balls.Length != ballSpeeds.Length)
        {
            Debug.LogError("The number of balls and speeds must match!");
            return;
        }

        directions = new Vector3[balls.Length];

        // Initialize random directions for each ball
        for (int i = 0; i < balls.Length; i++)
        {
            // ✅ UnityEngine.Random 명시
            directions[i] = UnityEngine.Random.insideUnitSphere.normalized;
        }
    }

    void Update()
    {
        for (int i = 0; i < balls.Length; i++)
        {
            // Move the ball
            balls[i].transform.Translate(directions[i] * ballSpeeds[i] * Time.deltaTime);

            // Check for collisions with the box boundaries
            Vector3 ballPosition = balls[i].transform.position;

            if (Mathf.Abs(ballPosition.x) > boxSize.x / 2)
            {
                directions[i].x = -directions[i].x;
                ballPosition.x = Mathf.Sign(ballPosition.x) * boxSize.x / 2;
            }

            if (Mathf.Abs(ballPosition.y) > boxSize.y / 2)
            {
                directions[i].y = -directions[i].y;
                ballPosition.y = Mathf.Sign(ballPosition.y) * boxSize.y / 2;
            }

            if (Mathf.Abs(ballPosition.z) > boxSize.z / 2)
            {
                directions[i].z = -directions[i].z;
                ballPosition.z = Mathf.Sign(ballPosition.z) * boxSize.z / 2;
            }

            balls[i].transform.position = ballPosition;
        }
    }
}
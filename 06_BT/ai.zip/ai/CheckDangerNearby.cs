using UnityEngine;

namespace TheKiwiCoder {
    /// <summary>
    /// 🧠 [행동 노드] CheckDangerNearby
    /// 
    /// 개구리 주변의 'Stone' 태그 오브젝트(돌)를 감지하여
    /// 가장 가까운 돌의 X좌표와 거리 정보를 Blackboard에 저장합니다.
    /// 감지 결과에 따라 isDangerNearby 값을 true/false로 업데이트합니다.
    /// </summary>
    public class CheckDangerNearby : ActionNode {

        [Tooltip("돌을 감지할 최대 X 거리")]
        public float detectionRange = 5.5f;  // 돌을 인식할 수 있는 최대 감지 거리

        /// <summary>
        /// 노드 실행이 시작될 때 한 번 호출 (여기서는 별도 초기화 없음)
        /// </summary>
        protected override void OnStart() { }

        /// <summary>
        /// 노드가 종료될 때 한 번 호출 (디버깅용 로그 출력)
        /// </summary>
        protected override void OnStop() {
            Debug.Log("🧠 CheckDangerNearby 종료됨");
        }

        /// <summary>
        /// 매 프레임마다 실행되는 핵심 함수
        /// 돌을 감지하고 Blackboard를 갱신한 뒤 상태를 반환합니다.
        /// </summary>
        protected override State OnUpdate() {
            // 🟩 CustomBlackboard로 캐스팅 (AI 전용 기억 저장소)
            CustomBlackboard bb = blackboard as CustomBlackboard;

            // 🔸 Blackboard나 Context가 없으면 실패 처리
            if (bb == null || context == null) {
                return State.Failure;
            }

            // 🔹 현재 씬의 모든 "Stone" 태그 오브젝트를 찾아 배열로 저장
            GameObject[] stones = GameObject.FindGameObjectsWithTag("Stone");
            if (stones == null || stones.Length == 0)
                return State.Failure;  // 감지할 돌이 없으면 실패로 반환

            // 🔸 가장 가까운 돌을 찾기 위한 변수 초기화
            GameObject nearest = null;
            float minDist = float.MaxValue;

            // 🔹 모든 돌 오브젝트를 순회하면서 가장 가까운 돌 탐색
            foreach (GameObject stone in stones) {
                if (stone == null) continue;

                // ✅ X축 거리만 계산 (세로(Y) 방향은 무시)
                float distX = Mathf.Abs(context.transform.position.x - stone.transform.position.x);

                // 🔸 가장 가까운 돌 갱신
                if (distX < minDist) {
                    minDist = distX;
                    nearest = stone;
                }
            }

            // 🔹 감지 거리 내에 돌이 존재하면 Blackboard 갱신
            if (nearest != null && minDist <= detectionRange) {
                bb.isDangerNearby = true;                        // 위험 감지 상태로 설정
                bb.dangerX = nearest.transform.position.x;        // 돌의 X 위치 저장
                Debug.Log($"⚠️ 돌 감지됨! X={bb.dangerX:F2}, 거리={minDist:F2}");
                return State.Success;                             // 감지 성공
            }

            // 🔸 감지 범위 내에 돌이 없으면 위험 아님 상태로 초기화
            bb.isDangerNearby = false;
            return State.Failure;  // 감지 실패
        }
    }
}
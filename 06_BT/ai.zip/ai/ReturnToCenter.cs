using UnityEngine;

namespace TheKiwiCoder {
    /// <summary>
    /// ↩️ [행동 노드] ReturnToCenter
    /// 
    /// 개구리가 돌을 피한 후, 다시 화면 중앙으로 복귀하는 행동을 담당합니다.
    /// 중앙 좌표(centerX)를 기준으로 현재 위치를 비교해 방향을 결정하고,
    /// 일정 오차(0.05f) 이내로 접근하면 복귀를 완료(Success)로 반환합니다.
    /// </summary>
    public class ReturnToCenter : ActionNode {

        [Tooltip("개구리가 복귀할 목표 X좌표 (기본값: 0 = 중앙)")]
        public float centerX = 0f;

        [Tooltip("복귀 이동 속도")]
        public float moveSpeed = 2f;

        /// <summary>
        /// 노드 실행이 시작될 때 1회 호출
        /// </summary>
        protected override void OnStart() {
            Debug.Log("↩️ 중앙 복귀 시작");
        }

        /// <summary>
        /// 노드가 종료될 때 1회 호출 (복귀 완료 시점)
        /// </summary>
        protected override void OnStop() {
            Debug.Log("✅ 중앙 복귀 완료");
        }

        /// <summary>
        /// 매 프레임마다 실행되는 메인 로직
        /// 중앙 위치로 개구리를 이동시킵니다.
        /// </summary>
        protected override State OnUpdate() {
            // 🟢 현재 개구리의 Transform 가져오기
            Transform player = context.transform;

            // 이동 방향 초기화
            float moveDir = 0f;

            // 📏 중앙에서 일정 거리 이상 떨어져 있으면 이동 시작
            if (Mathf.Abs(centerX - player.position.x) > 0.05f) {
                // 🔸 방향 결정 (+면 오른쪽, -면 왼쪽)
                moveDir = Mathf.Sign(centerX - player.position.x);

                // 🏃 중앙 방향으로 이동 (Time.deltaTime으로 프레임 보정)
                player.position += new Vector3(moveDir * moveSpeed * Time.deltaTime, 0, 0);

                // 🪄 디버그 로그로 이동 상황 출력
                Debug.Log($"↩️ 복귀 중... PlayerX={player.position.x:F2}");

                // 이동 중이므로 Running 상태 반환
                return State.Running;
            }

            // ✅ 거의 중앙(±0.05f 이내)에 도달했을 경우
            // 중앙 좌표로 정확히 맞추고 성공 반환
            player.position = new Vector3(centerX, player.position.y, player.position.z);
            return State.Success;
        }
    }
}
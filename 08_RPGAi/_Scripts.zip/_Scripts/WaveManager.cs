using UnityEngine;

public class WaveManager : MonoBehaviour
{
    [Header("References")]
    public Transform player;
    public Transform boss;
    public EnemyGenerator enemyGenerator;

    [Header("Debug Info")]
    public float distanceToBoss;
    public int currentWaveLevel;

    private int lastWave = 0;
    private float checkInterval = 0.3f; // 더 빠른 반응
    private float timer = 0f;

    private bool enemyGeneratorReady = false;

    void Start()
    {
        // 보스 자동 검색
        if (boss == null)
        {
            GameObject bossObj = GameObject.FindGameObjectWithTag("Boss");
            if (bossObj != null)
                boss = bossObj.transform;
        }

        // 플레이어 자동 검색
        if (player == null)
        {
            GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
            if (playerObj != null)
                player = playerObj.transform;
        }
    }

    void Update()
    {
        // EnemyGenerator 준비 여부 체크 (floorCached, roomsCached 설정되었는지 확인)
        if (!enemyGeneratorReady)
        {
            if (enemyGenerator != null &&
                enemyGenerator.HasFloorAndRoomsReady())
            {
                enemyGeneratorReady = true;
                Debug.Log("[WaveManager] EnemyGenerator 준비 완료!");
            }
            else return; 
        }

        // 일정 시간마다 계산
        timer += Time.deltaTime;
        if (timer < checkInterval) return;
        timer = 0f;

        if (player == null || boss == null) return;

        // 1) 거리 계산
        distanceToBoss = Vector3.Distance(player.position, boss.position);

        // 2) 웨이브 레벨 계산
        int calculatedWave = GetWaveLevel(distanceToBoss);

        // 웨이브는 오르기만 하고 내려가지 않는다 (스폰 폭주 방지)
        currentWaveLevel = Mathf.Max(currentWaveLevel, calculatedWave);

        // 3) 웨이브가 새롭게 증가했으면 스폰
        if (currentWaveLevel != lastWave)
        {
            Debug.Log($"[WaveManager] Wave 증가: {lastWave} → {currentWaveLevel}");

            if (enemyGenerator != null)
                enemyGenerator.SpawnWave(currentWaveLevel);

            lastWave = currentWaveLevel;
        }
    }

    // 거리 → 웨이브 레벨 변환
    int GetWaveLevel(float d)
    {
        if (d > 15f) return 1;
        if (d > 10f) return 2;
        if (d > 6f)  return 3;
        return 4;
    }
}

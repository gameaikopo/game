using System.Collections.Generic;
using UnityEngine;

public class EnemyGenerator : MonoBehaviour
{
    [Header("Enemy Prefabs")]
    [SerializeField] private GameObject enemyPrefab1;
    [SerializeField] private GameObject enemyPrefab2;
    [SerializeField] private GameObject enemyPrefab3;

    [Header("Enemy Settings")]
    [SerializeField] private int enemiesPerRoom = 3;

    private List<GameObject> enemies = new List<GameObject>();

    // 🔥 웨이브 스폰을 위해 던전 데이터 캐싱
    private HashSet<Vector2Int> floorCached;
    private List<BoundsInt> roomsCached;

    // GridMap reference (for world center position)
    private GridMap gridMap;

    private void Awake()
    {
        gridMap = FindObjectOfType<GridMap>();

        if (gridMap == null)
            Debug.LogError("[EnemyGenerator] GridMap을 찾을 수 없습니다!");
    }

    // (Vector2Int) 셀 → (Vector3) 타일 중앙 worldPosition 변환
    private Vector3 ToWorldPosition(Vector2Int cellPos)
    {
        Vector3Int tilePos = new Vector3Int(cellPos.x, cellPos.y, 0);
        return gridMap.floorTilemap.CellToWorld(tilePos) + new Vector3(0.5f, 0.5f, 0);
    }

    // --------------------------------------------------------
    //   초기 방(Room) 정적 생성
    // --------------------------------------------------------
    public void GenerateEnemies(HashSet<Vector2Int> floor, List<BoundsInt> roomsList)
    {
        floorCached = floor;
        roomsCached = roomsList;

        ClearEnemies();
        PlaceNewEnemies(floor, roomsList);
    }

    private void ClearEnemies()
    {
        foreach (GameObject enemy in enemies)
        {
            if (enemy != null)
                Destroy(enemy);
        }
        enemies.Clear();
    }

    private void PlaceNewEnemies(HashSet<Vector2Int> floor, List<BoundsInt> roomsList)
    {
        foreach (var room in roomsList)
        {
            List<Vector2Int> roomFloorPositions = new List<Vector2Int>();

            // 방 내부 모든 유효한 타일 수집
            for (int col = room.xMin + 1; col < room.xMax; col++)
            {
                for (int row = room.yMin + 1; row < room.yMax; row++)
                {
                    Vector2Int position = new Vector2Int(col, row);

                    if (floor.Contains(position) &&
                        !IsOccupied(position, "Player") &&
                        !IsOccupied(position, "Coin") &&
                        !IsOccupied(position, "Boss"))
                    {
                        roomFloorPositions.Add(position);
                    }
                }
            }

            // Enemy 1,2,3 순서대로 기본 생성
            List<GameObject> prefabList = new List<GameObject>
            { 
                enemyPrefab1, enemyPrefab2, enemyPrefab3
            };

            for (int i = 0; i < enemiesPerRoom && roomFloorPositions.Count > 0; i++)
            {
                int idx = Random.Range(0, roomFloorPositions.Count);
                Vector2Int spawnCell = roomFloorPositions[idx];
                roomFloorPositions.RemoveAt(idx);

                int prefabIndex = i % prefabList.Count;
                GameObject prefab = prefabList[prefabIndex];

                // 타일 중앙 좌표로 생성
                Vector3 spawnPos = ToWorldPosition(spawnCell);
                GameObject enemy = Instantiate(prefab, spawnPos, Quaternion.identity);
                enemies.Add(enemy);

                Debug.Log($"[EnemyGenerator] 기본 적 생성: {prefab.name} @ {spawnCell} → {spawnPos}");
            }
        }
    }

    // --------------------------------------------------------
    //   웨이브 기반 추가 스폰 기능
    // --------------------------------------------------------
    public void SpawnWave(int waveLevel)
    {
        if (floorCached == null || roomsCached == null)
        {
            Debug.LogWarning("[EnemyGenerator] GenerateEnemies가 먼저 호출되어야 합니다!");
            return;
        }

        int extraCount = waveLevel * 2;

        Debug.Log($"[EnemyGenerator] Wave {waveLevel} 추가 생성 시작! Room당 {extraCount}마리");

        foreach (var room in roomsCached)
        {
            List<Vector2Int> roomFloorPositions = new List<Vector2Int>();

            for (int col = room.xMin + 1; col < room.xMax; col++)
            {
                for (int row = room.yMin + 1; row < room.yMax; row++)
                {
                    Vector2Int pos = new Vector2Int(col, row);

                    if (floorCached.Contains(pos) && !IsOccupied(pos, "Player"))
                    {
                        roomFloorPositions.Add(pos);
                    }
                }
            }

            for (int i = 0; i < extraCount && roomFloorPositions.Count > 0; i++)
            {
                int idx = Random.Range(0, roomFloorPositions.Count);
                Vector2Int spawnCell = roomFloorPositions[idx];
                roomFloorPositions.RemoveAt(idx);

                GameObject prefab = GetRandomEnemyPrefab();

                // 웨이브 스폰 역시 중앙 좌표로 생성
                Vector3 spawnPos = ToWorldPosition(spawnCell);
                GameObject enemy = Instantiate(prefab, spawnPos, Quaternion.identity);
                enemies.Add(enemy);

                Debug.Log($"[Wave] 추가 Enemy 생성: {prefab.name} @ {spawnCell} → {spawnPos}");
            }
        }
    }

    // --------------------------------------------------------
    //   유틸리티 함수들
    // --------------------------------------------------------
    private bool IsOccupied(Vector2Int position, string tag)
    {
        // 타일 중앙 기준으로 검사해야 함
        Vector2 centerPos = new Vector2(position.x + 0.5f, position.y + 0.5f);
        Collider2D[] hits = Physics2D.OverlapPointAll(centerPos);

        foreach (Collider2D hit in hits)
        {
            if (hit.CompareTag(tag))
                return true;
        }
        return false;
    }

    private GameObject GetRandomEnemyPrefab()
    {
        int r = Random.Range(0, 3);
        switch (r)
        {
            case 0: return enemyPrefab1;
            case 1: return enemyPrefab2;
            default: return enemyPrefab3;
        }
    }

    // WaveManager에서 EnemyGenerator가 준비되었는지 확인하기 위한 함수
    public bool HasFloorAndRoomsReady()
    {
        return floorCached != null && roomsCached != null;
    }
}
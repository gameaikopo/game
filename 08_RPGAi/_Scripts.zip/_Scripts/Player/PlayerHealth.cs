using UnityEngine;
using System.Collections;

public class PlayerHealth : MonoBehaviour
{
    [SerializeField] private int maxHealth = 200;
    [SerializeField] private HealthBar healthBar;
    [SerializeField] private int damageFromEnemy = 10;
    [SerializeField] private int bossAttackDamage = 20;
    [SerializeField] private GameOverMenu gameOverMenu; // Reference to the Game Over menu script

    private int currentHealth;
    private Animator animator;

    private bool isInvincible = false;  // 🔥 무적 모드 플래그

    private void Start()
    {
        InitializeHealth();
        animator = GetComponent<Animator>();
    }

    private void Update()
    {
        // 🔥 단축키 1 → 무적 모드 ON/OFF 토글
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            isInvincible = !isInvincible;
            Debug.Log("무적 모드 : " + (isInvincible ? "ON" : "OFF"));
        }
    }

    private void InitializeHealth()
    {
        currentHealth = maxHealth;
        healthBar.SetMaxHealth(maxHealth);
    }

    public void TakeDamage(int damage)
    {
        if (currentHealth <= 0) return;

        // 🔥 무적일 때 데미지 무시
        if (isInvincible)
        {
            Debug.Log("무적 모드: 데미지 무시됨 (" + damage + ")");
            return;
        }

        currentHealth -= damage;
        healthBar.SetHealth(currentHealth);

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    private void Die()
    {
        animator.SetTrigger("Die");
        Debug.Log("Player died.");
        StartCoroutine(HandleDeath());
    }

    private IEnumerator HandleDeath()
    {
        yield return new WaitForSeconds(0.5f);

        if (gameOverMenu != null)
        {
            gameOverMenu.ShowGameOverMenu();
        }
        else
        {
            Debug.LogWarning("Game Over menu is not assigned or found.");
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (currentHealth <= 0) return;

        // 🔥 무적일 때 충돌데미지 무시
        if (isInvincible) return;

        if (collision.gameObject.CompareTag("Enemy"))
        {
            TakeDamage(damageFromEnemy);
        }
        else if (collision.gameObject.CompareTag("Boss"))
        {
            TakeDamage(bossAttackDamage);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (currentHealth <= 0) return;

        if (other.gameObject.CompareTag("HealthPotion"))
        {
            HealthPotion healthPotion = other.gameObject.GetComponent<HealthPotion>();
            if (healthPotion != null)
            {
                Heal(healthPotion.healAmount);
                Destroy(other.gameObject);
            }
        }
    }

    public void Heal(int healAmount)
    {
        if (currentHealth <= 0) return;

        currentHealth = Mathf.Min(currentHealth + healAmount, maxHealth);
        healthBar.SetHealth(currentHealth);
    }
}
using UnityEngine;
using UnityEngine.Tilemaps;
using System.Collections;
using System.Collections.Generic;

public class GridMap : MonoBehaviour
{
    [Header("Tilemaps")]
    public Tilemap floorTilemap;
    public Tilemap wallTilemap;

    private Vector2Int gridSize;
    public float cellSize = 1f;

    public Node[,] grid;
    public List<Node> path; // For debug drawing

    void Start()
    {
        StartCoroutine(InitializeGridDelayed());
    }

    IEnumerator InitializeGridDelayed()
    {
        // Wait 1 frame so dungeon generation finishes first
        yield return null;
        InitializeGrid();
    }

    // ----------------------------------------------------------------------
    // GRID INITIALIZATION
    // ----------------------------------------------------------------------
    public void InitializeGrid()
    {
        FindGridSize();
        CreateGrid(gridSize.x, gridSize.y);
    }

    void FindGridSize()
    {
        BoundsInt floorBounds = floorTilemap.cellBounds;
        BoundsInt wallBounds = wallTilemap.cellBounds;

        BoundsInt combinedBounds = floorBounds;
        combinedBounds.xMin = Mathf.Min(floorBounds.xMin, wallBounds.xMin);
        combinedBounds.yMin = Mathf.Min(floorBounds.yMin, wallBounds.yMin);
        combinedBounds.xMax = Mathf.Max(floorBounds.xMax, wallBounds.xMax);
        combinedBounds.yMax = Mathf.Max(floorBounds.yMax, wallBounds.yMax);

        gridSize = new Vector2Int(combinedBounds.size.x, combinedBounds.size.y);
    }

    void CreateGrid(int width, int height)
    {
        grid = new Node[width, height];

        BoundsInt combinedBounds = wallTilemap.cellBounds;
        combinedBounds.xMin = Mathf.Min(floorTilemap.cellBounds.xMin, wallTilemap.cellBounds.xMin);
        combinedBounds.yMin = Mathf.Min(floorTilemap.cellBounds.yMin, wallTilemap.cellBounds.yMin);
        combinedBounds.xMax = Mathf.Max(floorTilemap.cellBounds.xMax, wallTilemap.cellBounds.xMax);
        combinedBounds.yMax = Mathf.Max(floorTilemap.cellBounds.yMax, wallTilemap.cellBounds.yMax);

        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                Vector3Int cellPos = new Vector3Int(x + combinedBounds.xMin, y + combinedBounds.yMin, 0);

                // Skip empty cells
                if (!floorTilemap.HasTile(cellPos) && !wallTilemap.HasTile(cellPos))
                    continue;

                Vector3 worldPoint =
                    wallTilemap.CellToWorld(cellPos) + new Vector3(cellSize * 0.5f, cellSize * 0.5f);

                bool walkable =
                    !wallTilemap.HasTile(cellPos) &&
                    floorTilemap.HasTile(cellPos);

                grid[x, y] = new Node(walkable, new Vector2Int(x, y), worldPoint);
            }
        }
    }

    // ----------------------------------------------------------------------
    // UPDATE GRID WHEN PROPS ARE SPAWNED
    // ----------------------------------------------------------------------
    public void MarkPropsAsObstacles(List<Vector2Int> propPositions)
    {
        if (grid == null)
        {
            Debug.LogWarning("[GridMap] grid is null, cannot mark props as obstacles.");
            return;
        }

        foreach (var pos in propPositions)
        {
            Vector3Int cellPosition = new Vector3Int(pos.x, pos.y, 0);

            if (!IsWithinGrid(cellPosition))
                continue;

            int gx = cellPosition.x - wallTilemap.cellBounds.xMin;
            int gy = cellPosition.y - wallTilemap.cellBounds.yMin;

            if (gx >= 0 && gx < grid.GetLength(0) &&
                gy >= 0 && gy < grid.GetLength(1))
            {
                if (grid[gx, gy] != null)
                {
                    grid[gx, gy].walkable = false; // Make tile blocked
                }
            }
        }
    }

    private bool IsWithinGrid(Vector3Int cellPos)
    {
        return cellPos.x >= wallTilemap.cellBounds.xMin &&
               cellPos.x < wallTilemap.cellBounds.xMax &&
               cellPos.y >= wallTilemap.cellBounds.yMin &&
               cellPos.y < wallTilemap.cellBounds.yMax;
    }

    // ----------------------------------------------------------------------
    // PATHFINDING ACCESS
    // ----------------------------------------------------------------------
    public Node GetNode(Vector3 worldPos)
    {
        Vector3Int cellPos = wallTilemap.WorldToCell(worldPos);

        if (!IsWithinGrid(cellPos))
        {
            Debug.LogWarning("[GridMap] worldPos outside grid.");
            return null;
        }

        int gx = cellPos.x - wallTilemap.cellBounds.xMin;
        int gy = cellPos.y - wallTilemap.cellBounds.yMin;

        if (grid != null &&
            gx >= 0 && gx < grid.GetLength(0) &&
            gy >= 0 && gy < grid.GetLength(1))
        {
            return grid[gx, gy];
        }

        Debug.LogWarning("[GridMap] GetNode index out of bounds.");
        return null;
    }

    public List<Node> GetNeighbours(Node node)
    {
        List<Node> neighbours = new List<Node>();

        for (int x = -1; x <= 1; x++)
        {
            for (int y = -1; y <= 1; y++)
            {
                if (x == 0 && y == 0)
                    continue;

                int nx = node.gridPosition.x + x;
                int ny = node.gridPosition.y + y;

                if (nx >= 0 && nx < gridSize.x &&
                    ny >= 0 && ny < gridSize.y)
                {
                    if (grid[nx, ny] != null)
                        neighbours.Add(grid[nx, ny]);
                }
            }
        }

        return neighbours;
    }

    // ----------------------------------------------------------------------
    // DEBUG DRAWING
    // ----------------------------------------------------------------------
    void OnDrawGizmos()
    {
        if (grid != null)
        {
            foreach (Node n in grid)
            {
                if (n == null) continue;

                Gizmos.color = (n.walkable) ? Color.white : Color.red;
                Gizmos.DrawCube(n.worldPosition, Vector3.one * (cellSize - 0.1f));
            }
        }

        if (path != null)
        {
            Gizmos.color = Color.green;
            for (int i = 0; i < path.Count - 1; i++)
            {
                Gizmos.DrawLine(path[i].worldPosition, path[i + 1].worldPosition);
            }
        }
    }
}
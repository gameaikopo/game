using UnityEngine;

public class BossScript : MonoBehaviour, IDamageable
{
    [Header("이동 관련")]
    public float speed = 5f;
    public Transform player;

    [Header("체력 관련")]
    public int maxHealth = 500;
    private int currentHealth;

    [Header("보스 체력바")]
    public GameObject healthBarPrefab;
    private HealthBarEnemy healthBarInstance;

    [Header("페이즈 관련")]
    private float bossTimer = 0f;
    private int currentPhase = 1;

    [Header("광폭화(Enrage) 설정")]
    public float enragePercent = 0.3f;   // 체력 30% 이하에서 발동
    private bool isEnraged = false;

    void Start()
    {
        currentHealth = maxHealth;

        // 보스 HP바 생성
        GameObject healthBarObject = Instantiate(healthBarPrefab, transform.position, Quaternion.identity);
        healthBarInstance = healthBarObject.GetComponentInChildren<HealthBarEnemy>();
    }

    void Update()
    {
        bossTimer += Time.deltaTime;   // 보스 전투 시간 증가

        HandlePhases();                // 시간 기반 페이즈 관리
        CheckEnrage();                 // 체력 기반 광폭화 체크
        MoveTowardsPlayer();           // 이동 AI

        UpdateHealthBarPosition();     // 체력바 위치 갱신
    }

    // -------------------------------------------------------------------
    // 플레이어 방향으로 이동
    // -------------------------------------------------------------------
    private void MoveTowardsPlayer()
    {
        if (player == null) return;

        Vector3 direction = (player.position - transform.position).normalized;
        transform.Translate(direction * speed * Time.deltaTime);
    }

    // -------------------------------------------------------------------
    // 체력바를 보스 머리 위에 고정
    // -------------------------------------------------------------------
    private void UpdateHealthBarPosition()
    {
        if (healthBarInstance != null)
        {
            healthBarInstance.transform.position =
                Camera.main.WorldToScreenPoint(transform.position + new Vector3(0, 2, 0));
        }
    }

    // -------------------------------------------------------------------
    // 보스 데미지 처리
    // -------------------------------------------------------------------
    public void TakeDamage(int damage)
    {
        currentHealth -= damage;

        if (healthBarInstance != null)
            healthBarInstance.UpdateHealthBar(maxHealth, currentHealth);

        // HP 0 이하 → 사망
        if (currentHealth <= 0)
        {
            Die();
        }
    }

    // -------------------------------------------------------------------
    // 시간 기반 페이즈 처리
    // -------------------------------------------------------------------
    private void HandlePhases()
    {
        // 10초 → Phase 2
        if (currentPhase == 1 && bossTimer >= 10f)
            ChangePhase(2);

        // 20초 → Phase 3
        if (currentPhase == 2 && bossTimer >= 20f)
            ChangePhase(3);

        // 30초 → Phase 4
        if (currentPhase == 3 && bossTimer >= 30f)
            ChangePhase(4);
    }

    // -------------------------------------------------------------------
    // 페이즈 전환 처리
    // -------------------------------------------------------------------
    private void ChangePhase(int newPhase)
    {
        currentPhase = newPhase;
        Debug.Log($"🔵 보스 페이즈 변경 → Phase {newPhase}");

        switch (newPhase)
        {
            case 2:
                HealToPercent(0.5f);  // 체력 50% 회복
                StartPhase2Pattern();
                break;

            case 3:
                HealToPercent(0.7f);  // 체력 70% 회복
                StartPhase3Pattern();
                break;

            case 4:
                HealToPercent(1.0f);  // 체력 100% 회복
                StartPhase4Pattern();
                break;
        }
    }

    // -------------------------------------------------------------------
    // 체력을 일정 비율까지 회복
    // -------------------------------------------------------------------
    private void HealToPercent(float percent)
    {
        int targetHealth = Mathf.RoundToInt(maxHealth * percent);

        if (currentHealth < targetHealth)
        {
            currentHealth = targetHealth;
            Debug.Log($"❤️ 보스 체력 {percent * 100}% 까지 회복 (현재 HP = {currentHealth})");

            if (healthBarInstance != null)
                healthBarInstance.UpdateHealthBar(maxHealth, currentHealth);
        }
    }

    // -------------------------------------------------------------------
    // 페이즈별 패턴들
    // -------------------------------------------------------------------
    private void StartPhase2Pattern()
    {
        Debug.Log("⚔ Phase 2 패턴 시작: 이동 속도 증가");
        speed = 6.5f;
    }

    private void StartPhase3Pattern()
    {
        Debug.Log("🔥 Phase 3 패턴 시작: 원거리 공격 시작");
        // 예: 투사체 발사 코루틴 시작
    }

    private void StartPhase4Pattern()
    {
        Debug.Log("💀 Phase 4 패턴 시작: 최종 광폭화 모드");
        speed = 8f;
        // 공격력 2배, 패턴 강화 등 추가 가능
    }

    // -------------------------------------------------------------------
    // 체력 기반 광폭화(Enrage)
    // -------------------------------------------------------------------
    private void CheckEnrage()
    {
        if (!isEnraged && currentHealth <= maxHealth * enragePercent)
        {
            EnterEnrage();
        }
    }

    private void EnterEnrage()
    {
        isEnraged = true;

        Debug.Log("💢 보스 광폭화(Enrage) 발동!!");
        speed *= 1.5f;

        // 보스 색상 빨갛게 변경 (시각적 효과)
        SpriteRenderer sr = GetComponent<SpriteRenderer>();
        if (sr != null)
            sr.color = Color.red;

        // 공격력 2배 증가 등 추가 기능 넣기 가능
    }

    // -------------------------------------------------------------------
    // 보스 사망 처리
    // -------------------------------------------------------------------
    private void Die()
    {
        Debug.Log("💀 보스가 쓰러졌다!");

        if (healthBarInstance != null)
            Destroy(healthBarInstance.gameObject);

        if (GameManager.instance != null)
            GameManager.instance.LoadVictoryScene(3f);

        Destroy(gameObject);
    }
}
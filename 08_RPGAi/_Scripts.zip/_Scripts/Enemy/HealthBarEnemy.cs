using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class HealthBarEnemy : MonoBehaviour
{
    [SerializeField] private float timeToDrain = 0.25f;
    [SerializeField] private Gradient gradient;

    // 바꾸기: 자식에서 Image 자동 찾기
    public Image image;

    private float targetFillAmount = 1f;
    private Coroutine drainHealthBarCoroutine;

    private void Awake()
    {
        // Image가 직접 붙어 있지 않다면 자식에서 찾아라
        if (image == null)
        {
            image = GetComponent<Image>();
            if (image == null)
                image = GetComponentInChildren<Image>();      // 🔥 자식에서 찾기
        }

        if (image == null)
        {
            Debug.LogError("[HealthBarEnemy] Image 컴포넌트를 찾을 수 없습니다! 프리팹을 확인하세요.");
        }
    }

    private void Start()
    {
        if (image != null)
        {
            UpdateHealthBarGradient();
        }
    }

    public void UpdateHealthBar(float maxHealth, float currentHealth)
    {
        if (image == null) return;

        targetFillAmount = currentHealth / maxHealth;

        if (drainHealthBarCoroutine != null)
            StopCoroutine(drainHealthBarCoroutine);

        drainHealthBarCoroutine = StartCoroutine(DrainHealthBar());
    }

    private IEnumerator DrainHealthBar()
    {
        if (image == null) yield break;

        float initialFillAmount = image.fillAmount;
        float elapsedTime = 0f;

        while (elapsedTime < timeToDrain)
        {
            elapsedTime += Time.deltaTime;
            image.fillAmount = Mathf.Lerp(initialFillAmount, targetFillAmount, elapsedTime / timeToDrain);
            UpdateHealthBarGradient();
            yield return null;
        }

        image.fillAmount = targetFillAmount;
        UpdateHealthBarGradient();
    }

    private void UpdateHealthBarGradient()
    {
        if (image == null) return;

        float fillAmount = Mathf.Clamp01(image.fillAmount);
        image.color = gradient.Evaluate(fillAmount);
    }
}
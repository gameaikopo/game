using System.Collections.Generic;
using UnityEngine;

public class EnemyScript : MonoBehaviour, IDamageable
{
    public float speed = 3f;
    public int maxHealth = 100;
    public float knockbackForce = 5f;
    public float knockbackDuration = 0.2f;

    public GameObject healthBarPrefab;
    public float pathUpdateInterval = 0.5f;

    private int currentHealth;
    private Transform player;
    private Rigidbody2D rb;
    private bool isKnockedBack = false;
    private float knockbackEndTime;
    private HealthBarEnemy healthBarInstance;
    private Pathfinding pathfinding;
    private GridMap gridMap;
    private List<Node> path;
    private int currentPathIndex = 0;
    private float nextPathUpdateTime = 0f;

    private void Start()
    {
        currentHealth = maxHealth;
        player = GameObject.FindGameObjectWithTag("Player")?.transform;
        rb = GetComponent<Rigidbody2D>();
        pathfinding = FindObjectOfType<Pathfinding>();
        gridMap = FindObjectOfType<GridMap>();

        // 체력바 생성
        if (healthBarPrefab != null)
        {
            healthBarInstance = Instantiate(healthBarPrefab, transform.position, Quaternion.identity)
                                .GetComponent<HealthBarEnemy>();
            healthBarInstance.UpdateHealthBar(maxHealth, currentHealth);
        }
    }

    private void Update()
    {
        if (isKnockedBack)
        {
            if (Time.time >= knockbackEndTime)
                isKnockedBack = false;

            return;
        }

        if (player != null && Time.time >= nextPathUpdateTime)
        {
            UpdatePath();
            nextPathUpdateTime = Time.time + pathUpdateInterval;
        }

        MoveAlongPath();
    }

    // --------------------------------------------------------
    // 경로 재계산
    // --------------------------------------------------------
    private void UpdatePath()
    {
        if (pathfinding == null) return;

        path = pathfinding.FindPath(transform.position, player.position);
        currentPathIndex = 0;

        // 방어 코드
        if (path == null || path.Count == 0)
            return;
    }

    // --------------------------------------------------------
    // 경로 따라 이동
    // --------------------------------------------------------
    private void MoveAlongPath()
    {
        // path가 없으면 이동 불가
        if (path == null || path.Count == 0) return;

        // ⛔ 방어 코드: 인덱스 초과 방지
        if (currentPathIndex >= path.Count)
        {
            rb.linearVelocity = Vector2.zero;
            return;
        }

        // 실제 이동 처리
        Vector3 targetPosition = path[currentPathIndex].worldPosition;
        Vector3 direction = (targetPosition - transform.position).normalized;
        rb.linearVelocity = direction * speed;

        // 다음 노드로 이동
        if (Vector3.Distance(transform.position, targetPosition) < 0.1f)
        {
            currentPathIndex++;

            // 다시 방어
            if (currentPathIndex >= path.Count)
            {
                rb.linearVelocity = Vector2.zero;
                return;
            }
        }
    }

    // --------------------------------------------------------
    // 데미지 처리
    // --------------------------------------------------------
    public void TakeDamage(int damage)
    {
        currentHealth -= damage;

        if (healthBarInstance != null)
            healthBarInstance.UpdateHealthBar(maxHealth, currentHealth);

        if (currentHealth <= 0)
            Die();
    }

    // --------------------------------------------------------
    // 사망 처리
    // --------------------------------------------------------
    private void Die()
    {
        Destroy(gameObject);
    }

    // --------------------------------------------------------
    // 넉백 처리
    // --------------------------------------------------------
    public void ApplyKnockback(Vector2 direction)
    {
        isKnockedBack = true;
        knockbackEndTime = Time.time + knockbackDuration;
        rb.linearVelocity = direction * knockbackForce;
    }
}
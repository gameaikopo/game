using UnityEngine;

public class TeleportToBoss : MonoBehaviour
{
    public Transform player;
    public Transform boss;

    public void Teleport()
    {
        if (player != null && boss != null)
        {
            // 보스 위치 약간 앞쪽으로 이동
            Vector3 targetPos = boss.position + new Vector3(0, -1.5f, 0);
            player.position = targetPos;

            Debug.Log("플레이어가 보스 위치로 이동했습니다.");
        }
        else
        {
            Debug.LogWarning("player 또는 boss Transform이 비어있습니다.");
        }
    }
}
using Unity.MLAgents;
using Unity.MLAgents.Actuators;
using Unity.MLAgents.Sensors;
using UnityEngine;
using SpinMotion;
using System.Collections.Generic;

public class AutoCarAgent : Agent
{
    public CarController car;
    public Rigidbody rb;
    public Transform nextWaypoint;

    private Vector3 startPos;
    private Quaternion startRot;

    private List<Transform> waypointList;
    private int currentWaypointIndex = 0;

    private void Start()
    {
        startPos = transform.position;
        startRot = transform.rotation;

        // 트랙의 AI Waypoints 가져오기
        Transform wpParent = GameObject.Find("AI Waypoints").transform;
        waypointList = new List<Transform>();

        foreach (Transform t in wpParent)
            waypointList.Add(t);

        // 첫 번째 웨이포인트 세팅
        nextWaypoint = waypointList[0];
    }

    public override void OnEpisodeBegin()
    {
        transform.position = startPos;
        transform.rotation = startRot;

        rb.linearVelocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;

        currentWaypointIndex = 0;
        nextWaypoint = waypointList[currentWaypointIndex];
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        sensor.AddObservation(rb.linearVelocity.magnitude);
        sensor.AddObservation(transform.forward);

        Vector3 dir = (nextWaypoint.position - transform.position).normalized;
        sensor.AddObservation(dir);

        sensor.AddObservation(CastRay(transform.forward));
        sensor.AddObservation(CastRay(-transform.right));
        sensor.AddObservation(CastRay(transform.right));
    }

    private float CastRay(Vector3 direction)
    {
        if (Physics.Raycast(transform.position + Vector3.up * 0.5f, direction,
            out RaycastHit hit, 20f))
        {
            return hit.distance / 20f;
        }
        return 1f;
    }

    public override void OnActionReceived(ActionBuffers actions)
    {
        float steer = Mathf.Clamp(actions.ContinuousActions[0], -1f, 1f);
        float accel = actions.ContinuousActions[1];

        float throttle = Mathf.Clamp01(accel);
        float brake = accel < 0 ? -accel : 0f;

        car.Move(steer, throttle, brake, 0f);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Waypoint"))
        {
            AddReward(0.2f);

            // 다음 웨이포인트로 이동
            currentWaypointIndex++;
            if (currentWaypointIndex >= waypointList.Count)
                currentWaypointIndex = 0;

            nextWaypoint = waypointList[currentWaypointIndex];
        }

        if (other.CompareTag("OffRoad"))
        {
            AddReward(-1f);
            EndEpisode();
        }
    }
}